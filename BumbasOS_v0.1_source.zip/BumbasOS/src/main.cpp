#include <M5Cardputer.h>
#include <SPI.h>
#include <SD.h>
#include <WiFi.h>
#include <BLEDevice.h>

// BumbasOS v0.1 - starter firmware for M5Stack Cardputer-Adv.
// Navigation: W/S or J/K = move, Enter = select, Esc/Backspace = back.
// Wi-Fi/BLE tools only perform passive discovery/diagnostics; no attacks.

static constexpr int SD_CS = 12;
static constexpr int SD_SCK = 40;
static constexpr int SD_MISO = 39;
static constexpr int SD_MOSI = 14;

bool sdReady = false;
String page = "home";
int selected = 0;
String noteBuffer;
String statusLine = "Starting...";
unsigned long lastDraw = 0;

const char* menuItems[] = {
  "Retro games (demo)", "Space shooter (demo)", "RPG (demo)", "Minesweeper (demo)",
  "Mantis encyclopedia", "Mantis log", "Coding lessons", "Code examples",
  "Wi-Fi scanner", "Wi-Fi signal info", "BLE scanner", "SD file browser",
  "Quick notes", "Calculator", "Clock / stopwatch", "System info", "Backup settings"
};
const int MENU_COUNT = sizeof(menuItems) / sizeof(menuItems[0]);

void drawHeader(const char* title) {
  M5Cardputer.Display.fillScreen(TFT_BLACK);
  M5Cardputer.Display.setTextColor(TFT_GREEN, TFT_BLACK);
  M5Cardputer.Display.setTextSize(1);
  M5Cardputer.Display.setCursor(4, 3);
  M5Cardputer.Display.println("BumbasOS  //  v0.1");
  M5Cardputer.Display.drawFastHLine(4, 15, 232, TFT_DARKGREEN);
  M5Cardputer.Display.setTextColor(TFT_WHITE, TFT_BLACK);
  M5Cardputer.Display.setCursor(4, 20);
  M5Cardputer.Display.println(title);
}

void drawHome() {
  drawHeader("MAIN MENU  (W/S + ENTER)");
  int first = selected - 4;
  if (first < 0) first = 0;
  if (first > MENU_COUNT - 7) first = MENU_COUNT - 7;
  for (int i = first; i < MENU_COUNT && i < first + 7; ++i) {
    int y = 35 + (i - first) * 13;
    if (i == selected) {
      M5Cardputer.Display.fillRect(3, y - 1, 234, 12, TFT_DARKGREEN);
      M5Cardputer.Display.setTextColor(TFT_BLACK, TFT_DARKGREEN);
      M5Cardputer.Display.setCursor(7, y);
      M5Cardputer.Display.print("> ");
    } else {
      M5Cardputer.Display.setTextColor(TFT_WHITE, TFT_BLACK);
      M5Cardputer.Display.setCursor(7, y);
      M5Cardputer.Display.print("  ");
    }
    M5Cardputer.Display.println(menuItems[i]);
  }
  M5Cardputer.Display.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
  M5Cardputer.Display.setCursor(4, 126);
  M5Cardputer.Display.printf("SD: %s", sdReady ? "ready" : "not found");
}

void drawMessage(const String& title, const String& a, const String& b = "") {
  drawHeader(title.c_str());
  M5Cardputer.Display.setCursor(5, 40);
  M5Cardputer.Display.setTextColor(TFT_WHITE, TFT_BLACK);
  M5Cardputer.Display.println(a);
  if (b.length()) M5Cardputer.Display.println(b);
  M5Cardputer.Display.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
  M5Cardputer.Display.setCursor(4, 124);
  M5Cardputer.Display.print("ESC/BKSP = back");
}

void ensureDirs() {
  if (!sdReady) return;
  SD.mkdir("/BumbasOS");
  SD.mkdir("/BumbasOS/notes");
  SD.mkdir("/BumbasOS/mantis");
  SD.mkdir("/BumbasOS/backups");
  SD.mkdir("/BumbasOS/games");
  SD.mkdir("/BumbasOS/lessons");
}

void showSD() {
  if (!sdReady) { drawMessage("MICROSD", "Card not mounted.", "Format as FAT32 and retry."); return; }
  drawHeader("MICROSD ROOT");
  File root = SD.open("/");
  int y = 37;
  File f = root.openNextFile();
  while (f && y < 112) {
    M5Cardputer.Display.setCursor(6, y);
    M5Cardputer.Display.setTextColor(f.isDirectory() ? TFT_CYAN : TFT_WHITE, TFT_BLACK);
    M5Cardputer.Display.print(f.isDirectory() ? "[DIR] " : "[FILE] ");
    String n = String(f.name());
    if (n.length() > 24) n = n.substring(0, 24);
    M5Cardputer.Display.println(n);
    y += 13;
    f = root.openNextFile();
  }
  root.close();
  M5Cardputer.Display.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
  M5Cardputer.Display.setCursor(4, 124);
  M5Cardputer.Display.print("Files shown from root only");
}

void runWifiScan() {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(false, false);
  drawMessage("WI-FI SCAN", "Scanning nearby networks...", "Passive scan only.");
  int n = WiFi.scanNetworks(false, true);
  drawHeader("WI-FI RESULTS");
  M5Cardputer.Display.setTextColor(TFT_WHITE, TFT_BLACK);
  if (n <= 0) {
    M5Cardputer.Display.setCursor(5, 40); M5Cardputer.Display.println("No networks found.");
  } else {
    int shown = n < 6 ? n : 6;
    for (int i = 0; i < shown; ++i) {
      M5Cardputer.Display.setCursor(4, 36 + i * 14);
      String ssid = WiFi.SSID(i);
      if (!ssid.length()) ssid = "<hidden SSID>";
      if (ssid.length() > 17) ssid = ssid.substring(0, 17);
      M5Cardputer.Display.printf("%s %d dBm ch%d", ssid.c_str(), WiFi.RSSI(i), WiFi.channel(i));
    }
  }
  WiFi.scanDelete();
  M5Cardputer.Display.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
  M5Cardputer.Display.setCursor(4, 124); M5Cardputer.Display.print("ESC/BKSP = back");
}

void runBleScan() {
  drawMessage("BLE SCAN", "Looking for BLE adverts...", "Passive discovery only.");
  BLEDevice::init("BumbasOS");
  BLEScan* scan = BLEDevice::getScan();
  scan->setActiveScan(false);
  scan->setInterval(100);
  scan->setWindow(80);
  BLEScanResults* results = scan->start(4, false);
  drawHeader("BLE RESULTS");
  int count = results ? results->getCount() : 0;
  if (count == 0) {
    M5Cardputer.Display.setCursor(5, 40); M5Cardputer.Display.setTextColor(TFT_WHITE, TFT_BLACK);
    M5Cardputer.Display.println("No BLE adverts found.");
  } else {
    int shown = count < 6 ? count : 6;
    for (int i = 0; i < shown; ++i) {
      BLEAdvertisedDevice d = results->getDevice(i);
      String label = d.haveName() ? String(d.getName().c_str()) : String(d.getAddress().toString().c_str());
      if (label.length() > 18) label = label.substring(0, 18);
      M5Cardputer.Display.setCursor(4, 36 + i * 14);
      M5Cardputer.Display.setTextColor(TFT_WHITE, TFT_BLACK);
      M5Cardputer.Display.printf("%s %d dBm", label.c_str(), d.getRSSI());
    }
  }
  scan->clearResults();
  M5Cardputer.Display.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
  M5Cardputer.Display.setCursor(4, 124); M5Cardputer.Display.print("ESC/BKSP = back");
}

void appendNote(const String& text) {
  if (!sdReady) { statusLine = "Insert microSD to save notes"; return; }
  File f = SD.open("/BumbasOS/notes/notes.txt", FILE_APPEND);
  if (f) { f.println(text); f.close(); statusLine = "Note saved to microSD"; }
  else statusLine = "Could not open notes file";
}

void openSelected() {
  switch (selected) {
    case 0: page = "demo"; drawMessage("RETRO ARCADE", "Game module placeholder.", "Next: add pixel-art games."); break;
    case 1: page = "demo"; drawMessage("SPACE SHOOTER", "Arcade module placeholder.", "No game engine yet."); break;
    case 2: page = "demo"; drawMessage("MINI RPG", "RPG module placeholder.", "Progress/XP can be added next."); break;
    case 3: page = "demo"; drawMessage("MINESWEEPER", "Minesweeper module placeholder.", "Game logic can be added next."); break;
    case 4: page = "mantis"; drawMessage("MANTIS ENCYCLOPEDIA", "Edit /BumbasOS/mantis/species.txt", "Put species notes on the SD card."); break;
    case 5: page = "mantislog"; drawMessage("MANTIS LOG", "Use notes.txt for now.", "A structured log is planned."); break;
    case 6: page = "lessons"; drawMessage("CODING LESSONS", "See /BumbasOS/lessons/", "Python and C++ examples included."); break;
    case 7: page = "examples"; drawMessage("CODE EXAMPLES", "See /BumbasOS/lessons/", "Cardputer sketches are C++."); break;
    case 8: page = "wifi"; runWifiScan(); break;
    case 9: page = "wifiinfo"; WiFi.mode(WIFI_STA); drawMessage("WI-FI SIGNAL", "Connect to your own network", "then add a connection profile."); break;
    case 10: page = "ble"; runBleScan(); break;
    case 11: page = "files"; showSD(); break;
    case 12: page = "notes"; noteBuffer = ""; drawMessage("QUICK NOTES", "Type on keyboard; Enter saves.", "Backspace deletes; Esc cancels."); break;
    case 13: page = "calc"; drawMessage("CALCULATOR", "Basic calculator module planned.", "Use phone/computer for now."); break;
    case 14: page = "clock"; drawMessage("CLOCK", "Uptime clock:", "Updates while this page is open."); break;
    case 15: page = "info"; drawHeader("SYSTEM INFO"); M5Cardputer.Display.setCursor(4, 38); M5Cardputer.Display.setTextColor(TFT_WHITE, TFT_BLACK); M5Cardputer.Display.printf("Chip: ESP32-S3\nFlash: %u MB\nSD: %s\nWi-Fi: 2.4 GHz\nBLE: supported", ESP.getFlashChipSize() / (1024 * 1024), sdReady ? "mounted" : "not mounted"); break;
    case 16: page = "backup"; if (sdReady) { File f = SD.open("/BumbasOS/backups/README.txt", FILE_WRITE); if (f) { f.println("BumbasOS backup folder. Copy your settings and data here."); f.close(); } } drawMessage("BACKUP", sdReady ? "Backup folder is ready." : "Insert microSD first.", "/BumbasOS/backups/"); break;
  }
}

void setup() {
  Serial.begin(115200);
  auto cfg = M5.config();
  M5Cardputer.begin(cfg, true);
  M5Cardputer.Display.setRotation(1);
  M5Cardputer.Display.setTextSize(1);
  SPI.begin(SD_SCK, SD_MISO, SD_MOSI, SD_CS);
  sdReady = SD.begin(SD_CS, SPI, 25000000);
  if (sdReady) ensureDirs();
  drawHome();
  Serial.println("BumbasOS v0.1 started. Navigation: W/S, Enter, Esc.");
}

void loop() {
  M5Cardputer.update();
  if (page == "clock" && millis() - lastDraw > 1000) {
    lastDraw = millis();
    drawHeader("UPTIME CLOCK");
    M5Cardputer.Display.setTextColor(TFT_WHITE, TFT_BLACK);
    M5Cardputer.Display.setCursor(5, 42);
    M5Cardputer.Display.printf("%lu seconds", millis() / 1000);
    M5Cardputer.Display.setCursor(5, 60);
    M5Cardputer.Display.printf("Battery/RTC module later");
    M5Cardputer.Display.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
    M5Cardputer.Display.setCursor(4, 124); M5Cardputer.Display.print("ESC/BKSP = back");
  }
  if (!M5Cardputer.Keyboard.isChange() || !M5Cardputer.Keyboard.isPressed()) { delay(10); return; }
  auto keys = M5Cardputer.Keyboard.keysState();
  bool back = keys.del || keys.esc;
  if (page == "home") {
    for (auto c : keys.word) {
      if (c == 's' || c == 'j') { selected = (selected + 1) % MENU_COUNT; drawHome(); }
      else if (c == 'w' || c == 'k') { selected = (selected - 1 + MENU_COUNT) % MENU_COUNT; drawHome(); }
    }
    if (keys.enter) openSelected();
  } else if (page == "notes") {
    if (back) { page = "home"; drawHome(); return; }
    if (keys.enter) { appendNote(noteBuffer); page = "home"; drawHome(); return; }
    for (auto c : keys.word) if (noteBuffer.length() < 180) noteBuffer += c;
    drawHeader("QUICK NOTES");
    M5Cardputer.Display.setTextColor(TFT_WHITE, TFT_BLACK);
    M5Cardputer.Display.setCursor(4, 36); M5Cardputer.Display.println("Enter=save / Esc=cancel");
    M5Cardputer.Display.setCursor(4, 55); M5Cardputer.Display.println(noteBuffer);
  } else if (back) {
    page = "home"; drawHome();
  } else if (page == "demo" || page == "mantis" || page == "mantislog" || page == "lessons" || page == "examples" || page == "wifi" || page == "wifiinfo" || page == "ble" || page == "files" || page == "calc" || page == "clock" || page == "info" || page == "backup") {
    // These screens are informational until their full module is implemented.
  }
  delay(10);
}
