# BumbasOS v0.1 — M5Stack Cardputer-Adv

To jest **projekt źródłowy startera**, a nie gotowy plik `.bin`. Nie został tu skompilowany ani przetestowany na fizycznym urządzeniu.

## Co działa w tej wersji
- Menu obsługiwane klawiszami W/S lub J/K i Enter; Esc/Backspace wraca.
- Próba montowania microSD przez piny Cardputer-Adv.
- Przeglądanie wpisów w katalogu głównym karty.
- Prosty notatnik dopisujący tekst do `/BumbasOS/notes/notes.txt`.
- Skanowanie widocznych sieci Wi-Fi i pokazanie SSID/RSSI/kanału.
- Pasywne wykrywanie reklam BLE.
- Informacje o pamięci flash i stanie microSD.
- Katalogi i materiały startowe na karcie SD.

## Co jest jeszcze szkieletem / placeholderem
Gry retro, strzelanka, RPG, Saper, pełna encyklopedia i dziennik modliszek, kalkulator, pełny edytor, zaawansowane ustawienia, alarmy i emulator ROM-ów wymagają dalszej implementacji. Projekt nie uruchamia plików Python ani ROM-ów Game Boya.

## Wymagania
- M5Stack Cardputer-Adv (K132-Adv), ESP32-S3.
- Komputer z PlatformIO (VS Code) i kabel USB-C z transmisją danych.
- Karta microSD sformatowana jako FAT32.
- Internet na komputerze przy pierwszej kompilacji, aby PlatformIO pobrało platformę i bibliotekę.

## Biblioteki
PlatformIO pobierze `M5Cardputer` z oficjalnego repozytorium. `SPI`, `SD`, `WiFi` i `BLEDevice` są dostarczane przez pakiet Arduino-ESP32 używany przez platformę.

## Kompilacja
1. Rozpakuj ZIP.
2. Otwórz folder `BumbasOS` w VS Code z rozszerzeniem PlatformIO.
3. W panelu PlatformIO wybierz środowisko `m5stack-cardputer-adv`.
4. Uruchom **Build**. Jeśli biblioteka BLE/API zmieniła się w zainstalowanej wersji, mogą być potrzebne drobne poprawki.
5. Dopiero po udanym Build użyj **Upload** z podłączonym Cardputer-Adv.

W terminalu PlatformIO:
```sh
pio run -e m5stack-cardputer-adv
pio run -e m5stack-cardputer-adv -t upload
pio device monitor -b 115200
```

## Instalacja
Firmware wgrywa się do pamięci flash urządzenia przez USB-C — nie przez samo skopiowanie `.bin` na kartę microSD. Karta SD przechowuje notatki, lekcje i dane.

Jeśli urządzenie nie przechodzi w tryb wgrywania, oficjalna dokumentacja M5Stack opisuje procedurę trybu download: przełącz zasilanie na OFF, przytrzymaj G0, podłącz/zasil urządzenie, a następnie puść G0. Postępuj zgodnie z dokumentacją producenta.

## Pliki karty microSD
Skopiuj zawartość folderu `sdcard` na kartę FAT32, tak aby na karcie znalazł się folder `/BumbasOS/`.

## Bezpieczeństwo
Skanery Wi-Fi i BLE w tym starterze służą do pasywnej diagnostyki i nauki. Nie ma tu funkcji łamania haseł, zakłócania sieci ani atakowania cudzych urządzeń. Testuj wyłącznie sieci i urządzenia, do których masz zgodę.

## Dokumentacja
- Oficjalna strona Cardputer-Adv: https://docs.m5stack.com/en/core/Cardputer-Adv
- Biblioteka: https://github.com/m5stack/M5Cardputer
